package assignment2;

import java.util.Scanner;

/**
 *
 * @author 12102452
 */
// View class to display the menus and results
public class View {

    // Declare MAPAnalyser object
    private MAPAnalayser mAPAnalayser;

    // Constructor that initilaise the mAPAnalayser object
    public View(MAPAnalayser a) {
        this.mAPAnalayser = a;
    }

    // Method  to  display the menu and results
    public void commandLoop() {

        //  Display switch case Menu
        System.out.println("----------------------------------------------------------------------");
        System.out.println("The following commands are recognised:");
        System.out.println("Display this message                                   > 0");   // Display the menu message
        System.out.println("Display a specific subject record:                     > 1 id");// Display the specif subject record message
        System.out.println("Display records for all subject records within a range > 2 map1 map2");// Display the range message
        System.out.println("Display statistics (minimum, maximum and median)       > 3");// Display the min,max,median message
        System.out.println("Exit the application                                   > 9");// Display exit the application message

        // Create scanner object to take input from the user
        Scanner scan = new Scanner(System.in);
        String[] input = scan.nextLine().split("\\s+"); // Regex to split the white spaces

        // Switch case statment for choice in menu
        switch (input[0]) {
            // Display the main menu
            case "0":
                System.out.println("Case 0:");
                // Checking the valid no of input entered
                if (input.length != 1) {
                    System.out.println("----------------------------------------------------------------------");
                    System.out.println("\033[1;31m ERROR:Contains INVALID NO OF INPUT:" + (input.length) + " MUST CONTAIN  ONLY '0'");
                    this.commandLoop();
                    break;
                }
                this.commandLoop(); // Display the main menu

                break;
            // Display  the specific subject record
            case "1":
                System.out.println("Case 1:");
                // checking the valid of no of input entered
                if (input.length != 2) {
                    System.out.println("----------------------------------------------------------------------");
                    System.out.println("\033[1;31m ERROR:Contains INVALID NO OF INPUT:" + (input.length) + " MUST CONTAIN  ONLY 'id'");
                    this.commandLoop();
                    break;
                }
                String searchRecordId = input[1]; //  assign input1 to searchRecordId

                System.out.println("----------------------------------------------------------------------");
                System.out.println("Searching  record with ID:" + "'" + searchRecordId + "'"); // Display searching status in console

                // Find the specific record with searchReocrdId
                Record record = this.mAPAnalayser.find(searchRecordId);

                // Check wether the reocord is found or not
                if (record != null) {

                    System.out.println("----------------------------------------------------------------------");
                    System.out.println("RECORD FOUND:");// Display  record found message
                    System.out.println(record); // Display the found record

                } else {
                    System.out.println("----------------------------------------------------------------------");
                    System.out.println("\033[1;31m [ERROR]:SORRY:RECORD ID" + " '" + searchRecordId + "' " + "NOT FOUND"); // Display record not found message
                }
                this.commandLoop(); // Direct to the  display menu
                break;
            // Find the records in the specifed range i.e between input1 and input2
            case "2":
                //Case 2
                System.out.println("Case 2:");
                // checking the valid no of input entered
                if (input.length != 3) {
                    System.out.println("----------------------------------------------------------------------");
                    System.out.println("\033[1;31m ERROR: INVALID NO OF INPUT:" + (input.length) + " MUST CONTAIN ONLY 'MAP1' & 'MAP2");
                    this.commandLoop();
                    break;
                }
                int map1 = Integer.parseInt(input[1]); // Parse the user input[1] into integer and assign to input1
                int map2 = Integer.parseInt(input[2]); // Parse the user input[2] into integer and assign to input2

                // Checking whether the inputs are in range between 0 and 200 
                if (map1 >= 0 && map2 >= 0 && map1 <= 200 && map2 <= 200) {

                    // Check whether the input1 is greater than input2
                    if (map1 <= map2) {

                        System.out.println("----------------------------------------------------------------------");
                        System.out.println("Searching  records  between  map value:<" + map1 + "," + map2 + ">"); // Display the searching record message

                        //  Find the records in between input1 and input2
                        Record[] matchedRecords = this.mAPAnalayser.find(Integer.parseInt(input[1]), Integer.parseInt(input[2]));
                        // Check whether the record is  empty or not
                        if (matchedRecords == null) {

                            System.out.println("----------------------------------------------------------------------");
                            System.out.println("\033[1;31m [ERROR]:NO RECORDS FOUND IN THE RANGE:" + "<" + map1 + "," + map2 + ">"); // Display no record found messag

                        } else {
                            System.out.println("----------------------------------------------------------------------");
                            System.out.println("RECORDS FOUND:" + matchedRecords.length);  // Display record found message with its size
                            for (Record records : matchedRecords) {
                                System.out.println(records); // Display the  records
                            }
                        } // if-else ends

                    }// if-else ends
                    else {
                        System.out.println("----------------------------------------------------------------------");
                        System.out.println("\033[1;31m [ERROR]:INPUT2 MUST BE GREATER THAN INPUT1");  // Display input2 greater than input1

                    }
                } //if-else ends 
                else {
                    System.out.println("----------------------------------------------------------------------");
                    System.out.println("\033[1;31m [ERROR]:INVALID INPUT!: MUST BE IN THE RANGE 0-200"); //.Display input must be in range message 0-200

                }
                // Direct to main menu
                this.commandLoop();
                break;
            case "3":
                // checking the valid of no of input entered
                System.out.println("Case 3:");
                if (input.length != 1) {
                    System.out.println("----------------------------------------------------------------------");
                    System.out.println("\033[1;31m ERROR: INVALID NO OF INPUT:" + (input.length) + " MUST CONTAIN ONLY '3'");// Display error message
                    this.commandLoop();
                    break;
                }
                // Display the  lowest, highest, median
                System.out.println("----------------------------------------------------------------------");
                System.out.printf("\tSUMMARY STATISTICS:%n"); // Display lowest,highest,median message
                System.out.printf("\tHighest MAP value: %d%n", this.mAPAnalayser.highest()); // Display the maximum MAP value
                System.out.printf("\tLowest MAP value: %d%n", this.mAPAnalayser.lowest()); // Display the minimum MAP value
                System.out.printf("\tMedian MAP value: %d%n", this.mAPAnalayser.median());// Display the median MAP value
                // Direct to main menu
                this.commandLoop();
                break;
            // Exit system on  choice=9
            case "9":
                if (input.length != 1) {
                    System.out.println("----------------------------------------------------------------------");
                    System.out.println("\033[1;31m ERROR:INVALID NO OF INPUT:" + (input.length) + " MUST CONTAIN ONLY '9'");// Display error message
                    this.commandLoop();
                    break;
                }
                // Exit the system
                System.out.println("Case 9:");
                System.out.println("----------------------------------------------------------------------");
                System.out.println("Terminating Program"); // Display termination message
                System.exit(0);
                break;
            default:
                // Invalid input in switch case
                System.out.println("----------------------------------------------------------------------");
                System.out.println("\033[1;31m Error: INVALID  INPUT, Please try again");
                this.commandLoop(); // Display the main menu

        }// End of switch case
        System.out.println("----------------------------------------------------------------------");

    }
    // End of commandLoop method 
}
// End of View class
