package assignment2;

/**
 *
 * @author 12102452
 */
// Main class for Asssingment2
public class Assignment2 {

    /**
     * @param args the command line arguments
     */
    // Main method
    public static void main(String[] args) {

        System.out.println("************************APP-MAP-CALCULATOR-V2*************************");// Display in console
        MAPAnalayser mAPAnalayser = new MAPAnalayser();// Create MAPAnalayser object
        View view = new View(mAPAnalayser); // Create View object
        view.commandLoop();// call commandLopp method
    }

}
