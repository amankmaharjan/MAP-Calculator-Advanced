
package assignment2;

/**
 *
 * @author 12102452
 */
// Class
// Model Class for storing the Record 
public class Record{

    // Field declaration 
    private String id; // field for storing id's
    private int sbp; // field for storing sbp value
    private int dbp;// field for storing dbp value
    private int map;// field for storing map value
    private String category;// field for storing category value

    //  Argument constructor for initialising the record fileds
    public Record(String id, int sbp, int dbp, int map, String category) {
        this.id = id;
        this.sbp = sbp;
        this.dbp = dbp;
        this.map = map;
        this.category = category;
    }
    // Getter for id
    public String getId() {
        return id;
    }
    // Setter for id
    public void setId(String id) {
        this.id = id;
    }
    // Getter for SBP
    public int getSbp() {
        return sbp;
    }
    // Setter for id
    public void setSbp(int sbp) {
        this.sbp = sbp;
    }
    // Getter for DBP
    public int getDbp() {
        return dbp;
    }
    // Setter for DBP
    public void setDbp(int dbp) {
        this.dbp = dbp;
    }
    // Getter for MAP
    public int getMap() {
        return map;
    }

    // Setter for MAP
    public void setMap(int map) {
        this.map = map;
    }
     // Getter for Category
    public String getCategory() {
        return category;
    }

    // Setter for id
    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "<" +getId() + "," + getSbp() + "," + getDbp() + "," + getMap() + "," + getCategory()+">";
    }

  
}
