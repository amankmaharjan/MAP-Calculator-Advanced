package assignment2;

import java.util.Arrays;

/**
 *
 * @author 12102452
 */
// Utility class for performing  loading,sorting,searching records array
public class MAPAnalayser {

    // variable declarations
    private Record[] data;  // Array to store number ofrecords
    private int nrecords; //  variable that specifies the  number of records

    // No argument constructor that load and  sorts the record of  nrecords
    public MAPAnalayser() {
        nrecords = 10;// no fo records
        data = new Record[nrecords]; // initializing array
        this.loadFromTables();// load the data into data array
        this.sortById(); // sort byId
    }

    //  Method to find the  specific record
    public Record find(String id) {
        // Binary Search 
        // Variable initialisation
        int low = 0; // Variable for storing the lower limit 
        int high = data.length - 1; // Variable for storing the upper
        int index = -1; // Index variable for storing the match index  

        while (low <= high) {

            int mid = (low + high) / 2; // Calculate the middle index
            // Check in lower index
            if (data[mid].getId().compareTo(id) < 0) {
                low = mid + 1; // new Lower limit
            } else if (data[mid].getId().compareTo(id) > 0) {
                high = mid - 1; // new upper limit
            } else if (data[mid].getId().compareTo(id) == 0) {
                index = mid; // Match found
                break;
            }
        }
        // if not found, return null
        if (index == -1) {
            return null;
        }
        // if found, return the record of specified index
        return data[index];
    }

    // Method to find the  value between map  input1 and input2 ranges
    public Record[] find(int map1, int map2) {

        Record[] tempRecord = new Record[data.length]; // Create the tempRecord array to hold the matching records
        int matchCounter = 0; // Counter variable to record the number of records found
        for (Record record : data) {
            // Check each record whether  their  map value falls in between  input1 and input2 ranges
            if (record.getMap() >= map1 && record.getMap() <= map2) {
                tempRecord[matchCounter] = record;//  store the matched record
                matchCounter++; // increase the matchCounter  variable
            }
        } // for loop ends
        // Check if there is matched records or not
        if (matchCounter == 0) {
            return null;// return null if match not found
        }
        Record[] matchRecord = Arrays.copyOf(tempRecord, matchCounter); // copy the records  from tempRecord array to matchRecord array
        return matchRecord; // return matchRecord array

    }

    // Method to calculate the lowest map value record
    public int lowest() {
        // Sort the records by map value
        sortByMap();
        int lowest = data[0].getMap();// lowest is record having least index of the data array
        return lowest;
    }

    // Method to calculate the highest map value record
    public int highest() {
        // Sort the records by map value
        sortByMap();
        int highest = data[data.length - 1].getMap(); // highest is the record having highest index in the data array
        return highest;
    }

    // Method to calculate  the median
    public int median() {
        // Sort the records by map value
        sortByMap();
        int median; // Declare medianValue variable for storing median

        // check wehther the array size is even or not
        if (data.length % 2 == 0) {
            // For array size even, median is  the average of the two values; their indices are n/2 and n/2-1.  
            median = (data[data.length / 2].getMap() + data[data.length / 2 - 1].getMap()) / 2;

        } else {
            // For array size odd, median is the  value of index  size n/2
            median = data[data.length / 2].getMap();

        }
        return median; // return medianValue
    }

    // Method to  sort records by Id using selection sort alogrithm
    private void sortById() {
        // Selection sort
        for (int i = 0; i < data.length - 1; i++) {
            int lowestIndex = i;// Initialise the lowest index as i
            for (int j = i + 1; j < data.length; j++) {
                // Find the smallest record index
                if (data[j].getId().compareTo(data[lowestIndex].getId()) < 0) {
                    lowestIndex = j;//searching for lowest index  
                }
            }
            // Swap the smallest record to curent record
            Record smallerRecord = data[lowestIndex]; // Assign lowest index data reocord into smallerRecord object
            data[lowestIndex] = data[i]; // Swap the current  record into the lowestIndex record
            data[i] = smallerRecord; // Assign the  smallerRecord into the current record
        }

    }

    // Method to sort records by Map using selection sort alogrithm
    private void sortByMap() {
        // Selection sort
        for (int i = 0; i < data.length - 1; i++) {
            int lowestIndex = i; // Initialise the lowest index as i
            for (int j = i + 1; j < data.length; j++) {
                // Find the smallest record index
                if (data[j].getMap() < data[lowestIndex].getMap()) {
                    lowestIndex = j;//searching for lowest index  
                }
            }
            // Swap the smallest record to curent record
            Record smallerRecord = data[lowestIndex]; // Assign lowest index data record into smallerRecord object
            data[lowestIndex] = data[i]; // Swap the current  record into the lowestIndex record
            data[i] = smallerRecord; // Assign the  smallerRecord into the current record
        }
    }

    // Method to calculate & return map value
    public int value(double sbp, double dbp) {
        int map ;// Variable for storing MAP value
        map = (int) ((1.0 / 3.0) * sbp + (2.0 / 3.0) * dbp); // MAP value computation 
        return map; // Returning MAP value
    }

    // Method to load the value in the  data array
    private void loadFromTables() {

        // Variable initialization
        String[] id = {"S03", "S02", "S01", "S05", "S08", "S06","S07","S09","S04","S010"}; // Ids list
        int[] sbp = {90, 80, 120, 40,110, 60, 100,70,92,110}; // SBPs list
        int[] dbp = {80, 50, 100, 40, 30, 20, 70, 60, 90,56}; // DBPs list

        // Loop that loads the records in data array
        for (int i = 0; i < nrecords; i++) {
            int map = value(sbp[i], dbp[i]); // Map value calculation
            data[i] = new Record(id[i], sbp[i], dbp[i], map, classify(map)); // Data array initialization
        }
    }

    // Method to check category on the basis of map value
    public String classify(int map) {
        // Check whether the map value is "HIGH", "LOW" or "NORMAL"
        if (map >= 70 && map < 100) {
            return "NORMAL";   // Return  normal value
        } else if (map < 70) {
            return "LOW"; // Return low value
        } else {
            return "HIGH";// Return high value
        }
    }
}
